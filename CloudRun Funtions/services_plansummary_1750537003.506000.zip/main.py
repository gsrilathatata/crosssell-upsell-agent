from flask import Flask, request, jsonify
from google.cloud import bigquery

app = Flask(__name__)
client = bigquery.Client()

@app.route('/plansummary', methods=['POST'])
def plansummary(request):
    data = request.get_json()
    plan_name = data["plan_name"]
    print(plan_name)  # Output: Family Plan
    summary, plan_price, total_price, tax_amount = query_bigquery(plan_name)
    return jsonify({
        "planSummary": summary,
        "planPrice": plan_price,
        "totalPrice": total_price,
        "taxAmount": tax_amount
    })

def query_bigquery(plan_name):
    query = """
        SELECT summary, total_price, tax_amount, plan_price 
        FROM `hacker2025-team-46-dev.PlanDescription.plandescription` 
        WHERE LOWER(plan_name) = LOWER(@plan_name)
        LIMIT 1
    """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[bigquery.ScalarQueryParameter("plan_name", "STRING", plan_name)]
    )
    result = list(client.query(query, job_config=job_config).result())
    if result:
        row = result[0]
        return row.summary, row.plan_price, row.total_price, row.tax_amount
    else:
        return "Sorry, I couldn't find that plan.", None, None, None
if __name__ == '__main__':
    app.run()

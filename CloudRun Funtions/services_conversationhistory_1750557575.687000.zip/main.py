from google.cloud import bigquery
from datetime import datetime

client = bigquery.Client()
dataset_id = "Chathistory"
table_id = "conversationhistory"


from flask import Flask, request
from google.cloud import bigquery
from datetime import datetime

app = Flask(__name__)
client = bigquery.Client()

@app.route("/", methods=["POST"])
def webhook_entry(request):
    print("inside ryn")
    request_json = request.get_json(silent=True)

    customerId =  request_json.get("user_id")
    conversationhistory = request_json.get("queryInput")
    timestamp = datetime.utcnow().isoformat()
    print(conversationhistory)

    row = [{
        "customerId": customerId,
        "timestamp": timestamp,
        "conversationhistory": conversationhistory
    }]

    table_ref = client.dataset(dataset_id).table(table_id)
    errors = client.insert_rows_json(table_ref, row)

    if errors:
        return {"status": "error", "details": errors}, 500
    return {"status": "success"}, 200

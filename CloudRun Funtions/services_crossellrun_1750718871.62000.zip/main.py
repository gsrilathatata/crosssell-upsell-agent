from flask import Flask, request, jsonify
from google.cloud import bigquery

app = Flask(__name__)
client = bigquery.Client()

@app.route('/crosssell', methods=['POST'])
def crosssell(request):
    data = request.get_json()
    print(data)
    plan_name = data["plan_name"]
    
    print(plan_name)  # Output: Family Plan
    eligible_addon = query_bigquery(plan_name)
    return jsonify({"response": eligible_addon})

def query_bigquery(plan_name):
    print(plan_name)
    query = """
         SELECT eligible_addon FROM `hacker2025-team-46-dev.PlanDescription.crosssellplandetails` 
         WHERE LOWER(plan_name) = LOWER(@plan_name)
        LIMIT 1
    """
    print(query)
    job_config = bigquery.QueryJobConfig(
        query_parameters=[bigquery.ScalarQueryParameter("plan_name", "STRING", plan_name)]
    )
    result = list(client.query(query, job_config=job_config).result())
    return result[0].eligible_addon if result else "Sorry, I couldn't find that plan."

if __name__ == '__main__':
    app.run()

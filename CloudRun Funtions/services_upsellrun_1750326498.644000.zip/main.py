from flask import Flask, request, jsonify
from google.cloud import aiplatform
import os

app = Flask(__name__)

# Set your project and endpoint details
PROJECT_ID = "145075918218"
ENDPOINT_ID = "306153515196088320"
LOCATION = "us-central1"

# Initialize the Vertex AI client
aiplatform.init(project=PROJECT_ID, location=LOCATION)

@app.route('/predict', methods=['POST'])
def handle_chat_predict(request):
    try:
        instances = [request.get_json()]
       
        # Get the endpoint object
        endpoint = aiplatform.Endpoint(endpoint_name=ENDPOINT_ID)

        # Perform prediction
        prediction = endpoint.predict(instances=instances)

        # Return the prediction result
       # return jsonify(prediction.predictions)
        return prediction.predictions

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
